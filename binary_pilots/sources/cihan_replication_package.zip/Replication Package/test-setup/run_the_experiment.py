import math
import yaml
import os
import json
import re
import io
import sys

# Get the parent folder name
current_file_path = os.path.abspath(__file__)
part_of_path = os.path.dirname(os.path.dirname(current_file_path))

# Import other files
sys.path.append(f'{part_of_path}/helper_functions')
import helper_functions.prompt_creator as prompt_creator
import helper_functions.prompt_to_api as prompt_to_api
import helper_functions.testing as testing
import helper_functions.generate_prompts
import helper_functions.generate_responses
import generate_results


