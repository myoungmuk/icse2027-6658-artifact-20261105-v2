import os
import sys
import yaml
import json
import re

# Get the parent folder name
current_file_path = os.path.abspath(__file__)
part_of_path = os.path.dirname(os.path.dirname(current_file_path))

# Import other files
sys.path.append(os.path.join(part_of_path, "helper_functions"))
import helper_functions.prompt_creator as prompt_creator
import helper_functions.prompt_to_api as prompt_to_api
import helper_functions.testing as testing

def clean_string(s: str) -> str:
    start_marker = "```yaml"
    end_marker = "```"
    
    if s.startswith(start_marker):
        s = s[len(start_marker):]  
    
    if s.endswith(end_marker):
        s = s[:-len(end_marker)]  
    
    return s.strip()

NUM_OF_PROMPTS = 492
NUM_OF_QUESTIONS = 164

# Function to handle OpenAI API calls and save responses
def process_gpt_responses(model, desc):
    print(f"Process: {model} - {desc}")
    
    response_dir = os.path.join(part_of_path, "generated_responses", model, f"responses_{desc}")
    os.makedirs(response_dir, exist_ok=True)

    for i in range(NUM_OF_PROMPTS):
        index = i % NUM_OF_QUESTIONS
        prompt_file = os.path.join(part_of_path, "generated_prompts", f"prompts_{desc}", f"prompt_{index+1}.toml")

        parsed_content = prompt_creator.parse_toml(prompt_file)
        response = prompt_to_api.get_response(parsed_content.get('user', ''), model)

        response_path = os.path.join(response_dir, f"response_{i+1}.yaml")
        with open(response_path, 'w',encoding="utf-8") as file:
            content = response
            content = clean_string(content)
            file.writelines(content)

        if i % 50 == 0:
            print("iteration: ", i)
    print(f"Process finished: {model} - {desc}")

# Processing GPT responses
for model in ["gemini","gpt4o"]:
    for desc in ["with_desc", "without_desc"]:
            process_gpt_responses(model, desc)


# Processing ground truth responses
def process_ground_truth(model, desc):
    print(f"Process: {model} Ground Truth - {desc}")

    response_dir = os.path.join(part_of_path, "generated_responses", model, f"responses_{desc}", "ground_truth")
    os.makedirs(response_dir, exist_ok=True)

    for i in range(NUM_OF_QUESTIONS):
        prompt_file = os.path.join(part_of_path, "generated_prompts", f"prompts_{desc}", "ground_truth", f"prompt_{i+1}.toml")

        parsed_content = prompt_creator.parse_toml(prompt_file)
        response = prompt_to_api.get_response(parsed_content.get('user', ''), model)

        response_path = os.path.join(response_dir, f"response_{i+1}.yaml")
        with open(response_path, 'w',encoding="utf-8") as file:
            content = response
            content = clean_string(content)
            file.writelines(content)

        if i % 50 == 0:
            print("iteration: ", i)
    print(f"Process finished: {model} Ground Truth - {desc}")

# Running Ground Truth Processing
for model in ["gemini", "gpt4o"]:
    for desc in ["with_desc", "without_desc"]:
        process_ground_truth(model, desc)