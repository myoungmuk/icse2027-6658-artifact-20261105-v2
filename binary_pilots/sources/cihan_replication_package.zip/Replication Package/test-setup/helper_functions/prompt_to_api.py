# Get the parent folder name
import os
import sys
import subprocess
import sys
import time
# Function to check and install the 'openai' package if missing
def ensure_openai_installed():
    try:
        import openai
    except ModuleNotFoundError:
        print("⚠️ 'openai' module not found. Installing...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "openai"])
        import openai  # Import again after installation
        print("✅ 'openai' module installed successfully.")

# Ensure OpenAI module is installed
ensure_openai_installed()

current_file_path = os.path.abspath(__file__)
part_of_path = os.path.dirname(os.path.dirname(current_file_path))

sys.path.append(os.path.join(part_of_path, "helper_functions"))
import helper_functions.prompt_creator as prompt_creator
from openai import AzureOpenAI

client = AzureOpenAI(
    api_key="4zJBudNi5oHg8Teue6M3hYKH6HJPUn6uduJN9iCjyOo3MByc8fcxJQQJ99BBACYeBjFXJ3w3AAABACOGZ2vH",
    api_version="2024-08-01-preview",
    azure_endpoint="https://codereviewbotbot.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-08-01-preview"
)

import google.generativeai as genai
genai.configure(api_key="AIzaSyD7GEqEE_jRbZ2aUbXly9v40gRpXmzxKVo")
g_model = genai.GenerativeModel("gemini-2.0-flash")

#client = OpenAI(api_key="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")

'''
def get_response(user, model):
    if model == "gpt4":
        #api_model = "o3-mini"
        response = g_model.generate_content(user)
        return response.text

    elif model == "gpt4o":
        api_model = "gpt-4o"
        response = client.chat.completions.create(
        model=api_model,
        messages=[
            {"role": "user", "content": user}
        ]
    )


        return response.choices[0].message.content
    else:
        print("Choose a API model.")
        return
'''

def get_response(user, model):
    wait_time = 60  # Time to wait before retrying (in seconds)

    if model == "gemini":
        try:
            response = g_model.generate_content(user)  # Assuming this is Google Gemini
            return response.text
        except:
            print(f"Gemini Quota exceeded. Retrying in {wait_time} seconds...")
            time.sleep(wait_time)
            return get_response(user, model)  # Retry once

    elif model == "gpt4o":
        api_model = "gpt-4o"
        response = client.chat.completions.create(
            model=api_model,
            messages=[{"role": "user", "content": user}]
        )
        return response.choices[0].message.content
        try:
            api_model = "gpt-4o"
            response = client.chat.completions.create(
                model=api_model,
                messages=[{"role": "user", "content": user}]
            )
            return response.choices[0].message.content
        except:
            print(f"GPT-4o rate limit exceeded. Retrying in {wait_time} seconds...")
            time.sleep(wait_time)
            return get_response(user, model)  # Retry once

    else:
        print("Choose a valid API model.")
        return None
    